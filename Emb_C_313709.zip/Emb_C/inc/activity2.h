
#ifndef _activity2_h_
#define _activity2_h_

uint16_t ReadADC(uint8_t ch);
void InitADC();
#endif /** __activity2_h_ */
