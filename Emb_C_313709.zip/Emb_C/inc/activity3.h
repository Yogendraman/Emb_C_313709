
#ifndef __activity3_h__
#define __activity3_h__
#include<avr/io.h>

char OutPWM(uint16_t temp_value);
void InitPWM(void);
#endif
