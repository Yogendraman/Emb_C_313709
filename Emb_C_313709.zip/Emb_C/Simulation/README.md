# Activity 1  
|OFF|ON|
:--:|:--:
![1_OFF](https://github.com/nuPURohit/Embedded_C_LTTS/blob/main/simulation/activity1_OFF.png)|![1_ON](https://github.com/nuPURohit/Embedded_C_LTTS/blob/main/simulation/activity1_ON.png)

# Activity 2
|OFF|ON|
:--:|:--:
![2_OFF](https://github.com/nuPURohit/Embedded_C_LTTS/blob/main/simulation/activity2_OFF.png)|![2_ON](https://github.com/nuPURohit/Embedded_C_LTTS/blob/main/simulation/activity2_ON.png)

# Activity 3
|OFF|ON|
:--:|:--:
![3_OFF](https://github.com/nuPURohit/Embedded_C_LTTS/blob/main/simulation/activity3_OFF.png)|![3_ON](https://github.com/nuPURohit/Embedded_C_LTTS/blob/main/simulation/activity3_ON.png)

# Activity 4
|OFF|ON|
:--:|:--:
![4_OFF](https://github.com/nuPURohit/Embedded_C_LTTS/blob/main/simulation/activity4_OFF.png)|![4_ON](https://github.com/nuPURohit/Embedded_C_LTTS/blob/main/simulation/activity4_ON.png)
